# /summarize-chat

Save a summary of the current conversation to a `chats/` folder so future chats can pick up where this one left off.

## Triggers

Activate this skill when the user says any of:
- "summarize this chat"
- "save a summary"
- "what did we do?"
- `/summarize-chat`

## Behavior

### On startup (every conversation)

Before responding to the first message, look for a `chats/` folder in the current working directory. If it exists, read the 3 most recent files and briefly summarize what was done and any unfinished next steps. Keep this to 2-3 lines — just enough context to resume. Then respond to the user's message normally.

If no `chats/` folder exists, skip this step silently.

### Saving a summary

1. Create a `chats/` folder in the current working directory if it doesn't exist.
2. Write a markdown summary file.

**Filename format:** `YYYY-MM-DD_short-description.md`

Use today's date and a 2-4 word description of the main work done (e.g., `2026-03-30_module-reorganization.md`).

**File format:**

```markdown
# Chat: [short description]
**Date:** YYYY-MM-DD
**Repo:** [repo name] ([branch])

## What was done
- Bullet points of changes made

## Files changed
- List key files modified/created

## Next steps
- Anything left to do or follow up on
```

### Rules

- Keep summaries short (under 30 lines)
- Focus on what changed and what's unfinished — not play-by-play
- Use the repo name from the working directory, not the full path
- Include the git branch if relevant (e.g., working on a feature branch)
- If nothing meaningful was done, say so briefly rather than padding
